the path of the file is: /usr/share/X11/xkb/symbols
